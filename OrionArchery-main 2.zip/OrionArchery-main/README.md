group project for web development
